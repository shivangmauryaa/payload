# Windows - DPAPI

:warning: Content of this page has been moved to [InternalAllTheThings/redteam/evasion/windows-dpapi](https://swisskyrepo.github.io/InternalAllTheThings/redteam/evasion/windows-dpapi/)

* [List Credential Files](https://swisskyrepo.github.io/InternalAllTheThings/redteam/evasion/windows-dpapi/#list-credential-files)
* [DPAPI LocalMachine Context](https://swisskyrepo.github.io/InternalAllTheThings/redteam/evasion/windows-dpapi/#dpapi-localmachine-context)
* [Mimikatz - Credential Manager & DPAPI](https://swisskyrepo.github.io/InternalAllTheThings/redteam/evasion/windows-dpapi/#mimikatz---credential-manager--dpapi)
* [Hekatomb - Steal all credentials on domain](https://swisskyrepo.github.io/InternalAllTheThings/redteam/evasion/windows-dpapi/#hekatomb---steal-all-credentials-on-domain)
* [DonPAPI - Dumping DPAPI credz remotely](https://swisskyrepo.github.io/InternalAllTheThings/redteam/evasion/windows-dpapi/#donpapi---dumping-dpapi-credz-remotely)